# -*- coding: utf-8 -*-
"""
Central configuration for Course Materials Manager.
All user-editable settings live here.
"""

import os
from pathlib import Path

# ── Scan Paths ──────────────────────────────────────────────────
# Add any folders you want to index.  The folder's basename is used
# as the display name automatically.
DESKTOP = Path.home() / "Desktop"

# Primary scan directory list -- add / remove paths here.
# Uses pathlib.Path for cross-platform (Windows / macOS / Linux)
# path separator compatibility.  Forward slashes work everywhere.
SCAN_DIRS = [
    DESKTOP / "二课工作",
    DESKTOP / "大二上学期课程",
    DESKTOP / "学习",
    DESKTOP / "智慧交通双创",
    DESKTOP / "物联网工程设计与管理",
    DESKTOP / "物联网设备装调维护",
    DESKTOP / "物联网部署与运维",
    DESKTOP / "自考",
    DESKTOP / "奖项",
]

# Backward-compatible alias (old code may still reference SCAN_PATHS)
SCAN_PATHS = [str(p) for p in SCAN_DIRS]

# Auto-derived: (display_name, absolute_path) tuples
MONITORED_FOLDERS = [(p.name, str(p)) for p in SCAN_DIRS]

# ── Category Mapping ────────────────────────────────────────────
# Maps folder basename -> category label used in the dashboard.
# Folders not listed here are labeled "其他" (Other).
FOLDER_CATEGORY = {
    "二课工作": "二课",
    "大二上学期课程": "课程",
    "学习": "课程",
    "智慧交通双创": "项目",
    "物联网工程设计与管理": "课程",
    "物联网设备装调维护": "课程",
    "物联网部署与运维": "课程",
    "自考": "自考",
    "奖项": "奖项",
}

# ── Server ──────────────────────────────────────────────────────
SERVER_PORT = 8080

# ── Duplicate Detection ─────────────────────────────────────────
# Max file size (bytes) to compute MD5 during scan.
# Files larger than this are skipped for hashing (too slow).
MD5_MAX_SIZE = 500 * 1024 * 1024  # 500 MB

# ── Project Directories (do not change) ─────────────────────────
PROJECT_DIR = Path(__file__).resolve().parent.parent
SRC_DIR     = PROJECT_DIR / "src"
DATA_DIR    = PROJECT_DIR / "data"
OUTPUT_DIR  = PROJECT_DIR / "output"
DB_PATH     = DATA_DIR / "index.db"
HTML_PATH   = OUTPUT_DIR / "index.html"
JSON_PATH   = OUTPUT_DIR / "data.json"
TEMPLATE_PATH = PROJECT_DIR / "templates" / "dashboard.html"
